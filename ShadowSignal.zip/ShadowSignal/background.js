chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    const { action, data } = request;
    let apiUrl = 'https://your-website.com/api/';
    let endpoint;
  
    switch (action) {
      case 'send_sms':
        endpoint = 'send-sms';
        break;
      case 'make_call':
        endpoint = 'make-call';
        break;
      case 'send_email':
        endpoint = 'send-email';
        break;
    }
  
    fetch(apiUrl + endpoint, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(data)
    })
    .then(response => response.json())
    .then(data => {
      sendResponse({ message: 'Success!' });
    })
    .catch(error => {
      sendResponse({ message: 'Failed: ' + error });
    });
  
    return true;  // Keeps the message channel open for the async sendResponse
  });
  