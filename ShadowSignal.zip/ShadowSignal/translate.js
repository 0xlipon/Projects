function translatePage() {
    var iframe = document.querySelector('iframe');
    if (iframe) {
        var originalUrl = 'https://twilio.click-thunder.com/';  // Original URL to load
        var translatedUrl = 'https://translate.google.com/translate?hl=en&sl=auto&tl=en&u=' + encodeURIComponent(originalUrl);
        iframe.src = translatedUrl;
    }
}

window.onload = function() {
    translatePage();
};
