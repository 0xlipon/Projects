// popup.js

document.addEventListener('DOMContentLoaded', function () {
    const iframe = document.querySelector('iframe');
    
    iframe.onload = function() {
        const iframeDocument = iframe.contentDocument || iframe.contentWindow.document;

        // Example: Automatically click a button inside the iframe
        const button = iframeDocument.querySelector('#button-id'); // Replace with the actual ID or class
        if (button) {
            button.click();
        }
        
        // You can interact with other elements similarly
    };
});
